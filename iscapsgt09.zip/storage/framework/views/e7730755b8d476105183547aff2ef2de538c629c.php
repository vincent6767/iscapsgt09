<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>ISCAPSGT09</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/main.css')); ?>">
		<?php echo $__env->yieldContent('css'); ?>
	</head>
	<body>
		<div class="">
			<div class="black-header">
				<?php if(!Auth::guest()): ?>
					<div class="text-right">
						<a href="<?php echo e(url('/logout')); ?>" class="bigger"><i class="fa fa-btn fa-sign-out"></i>Logout</a>
					</div>
				<?php endif; ?>
				<?php echo $__env->yieldContent('header'); ?>
			</div>
			<?php echo $__env->yieldContent('errors'); ?>

			<?php if(Session::has('success')): ?>
				<div class="alert alert-success">
					<?php echo e(Session::get('success')); ?>

				</div>
			<?php endif; ?>
			<?php echo $__env->yieldContent('content'); ?>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo e(asset('/js/class.js')); ?>"></script>
		<?php echo $__env->yieldContent('js'); ?>
	</body>
</html>