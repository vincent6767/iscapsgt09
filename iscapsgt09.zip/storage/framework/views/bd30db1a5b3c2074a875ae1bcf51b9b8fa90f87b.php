

<?php $__env->startSection('js'); ?>
	<script type="text/javascript">
		view = new TestSendingDataView();
		controller = new TestingCyclingController(view);

		controller.posting('<?php echo e(url('/cycling')); ?>', 1000);
		
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>