

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
	<div class="bigger text-center">
		<h1>ISCAPS</h1>
		<h3>INTEGRATED AND SMART CLEAN AIR PURIFYING SYSTEM</h3>
	</div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="content"> 
		<div class="">
			<div class="white-title text-center">
				<h1>HI THERE! WELCOME TO</h1>
			</div>
		</div>
		<?php echo Form::model($user, ['url' => url(''), 'method' => 'POST', 'class' => 'form-horizontal']); ?>

			<div class="form-group">
				<?php echo Form::label('gender', 'Gender: ', ['class' => 'control-label col-sm-4']); ?>

				<div class="radio col-sm-4">
					<label class="control-label radio-inline"><input type="radio" name="gender" value="m" <?php echo e($user->is('m') ? 'checked' : ''); ?>>Male</label>
					<label class="control-label radio-inline"><input type="radio" name="gender" value="f" <?php echo e($user->is('f') ? 'checked' : ''); ?>>Female</label>
				</div>
			</div>
			<div class="form-group">
				<?php echo Form::label('age', 'Age: ', ['class' => 'control-label col-sm-4']); ?>

				<div class="col-sm-4"> 
					<?php echo Form::number('age', Request::old('age'), ['class' => 'form-control', 'id' => 'age']); ?>

					<span class="help-block" id="age-error">

					</span>
				</div>
				
			</div>
			<div class="form-group">
				<?php echo Form::label('weight', 'Weight: ', ['class' => 'control-label col-sm-4']); ?>

				<div class="col-sm-4"> 
					<?php echo Form::number('weight', Request::old('weight'), ['class' => 'form-control', 'id' => 'weight']); ?>

					<span class="help-block" id="weight-error">

					</span>
				</div>
				
			</div>
			<!-- Speedometer Container -->
			<div class="speedometer">
				<div class="speedometer-tag">
					<h2>HOW FAST</h2>
					<h4>YOU CAN GO?</h4>
				</div>
				<div class="container speedometer-container" id="speedometer">
				</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('calories', 'Calories: ', ['class' => 'control-label col-sm-4']); ?>

				<div class="col-sm-4"> 
					<?php echo Form::number('calories', 0, ['class' => 'form-control', 'readonly' => true]); ?>

				</div>
			</div>
			<div class="form-group">
				<?php echo Form::label('points', 'Points earned: ', ['class' => 'control-label col-sm-4']); ?>

				<div class="col-sm-4"> 
					<?php echo Form::number('points', $user->points, ['class' => 'form-control', 'readonly' => true]); ?>

				</div>
			</div>
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script src="https://code.highcharts.com/highcharts-more.js"></script>
	<script type="text/javascript" src="https://code.highcharts.com/modules/exporting.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('/js/speedometer.js')); ?>"></script>

	<script type="text/javascript">
		session = new CyclingSession(<?php echo e($session->id); ?>, '<?php echo e($session->start_time); ?>');
		
		user = new User(<?php echo e($user->age); ?>, <?php echo e($user->weight); ?>, <?php echo e($user->points); ?>, '<?php echo e($user->gender); ?>', session);
		
		view = new UserInformationView($('#speedometer').highcharts());

		calculator = new CaloriesCalculator(user);

		controller = new UserInformationController(view, user, calculator, '<?php echo e(url('/session-stop')); ?>');

		controller.initialize();

		controller.polling('<?php echo e(url('/get-updates')); ?>', 1000);
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>