

<?php $__env->startSection('header'); ?>
	<h2 class="text-center">ISCAPS GT09</h2>
	<h3 class="text-center">Testing Sending Data Page</h3>
	<h4 class="text-center">Happy birthday robert tan!</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div id="test-output">

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script type="text/javascript">
		view = new TestSendingDataView();

		controller = new TestingCyclingController(view);

		controller.startPolling('<?php echo e(action('TestingCyclingController@testGetUpdates')); ?>', 1000);
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>