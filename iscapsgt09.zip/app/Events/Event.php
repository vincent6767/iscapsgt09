<?php

namespace Iscapsgt09\Events;

abstract class Event
{
    //
}
